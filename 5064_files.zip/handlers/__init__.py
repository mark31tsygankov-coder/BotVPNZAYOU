from aiogram import Router

from .start import router as start_router
from .subscription import router as subscription_router
from .balance import router as balance_router
from .support import router as support_router
from .profile import router as profile_router
from .documents import router as documents_router
from .admin import router as admin_router


def setup_routers() -> Router:
    root = Router()
    root.include_router(start_router)
    root.include_router(subscription_router)
    root.include_router(balance_router)
    root.include_router(support_router)
    root.include_router(profile_router)
    root.include_router(documents_router)
    root.include_router(admin_router)
    return root
